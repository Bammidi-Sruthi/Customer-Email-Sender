from flask import Flask, request, jsonify
import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

@app.route('/upload-data', methods=['POST'])
def upload_data():
    file = request.files['file']
    data = pd.read_csv(file)
    return jsonify({"columns": list(data.columns)})

@app.route('/send-email', methods=['POST'])
def send_email():
    data = request.get_json()
    email_content = data['email_content']
    emails = data['emails']
    for email in emails:
        try:
            smtp = smtplib.SMTP('smtp.gmail.com', 587)
            smtp.starttls()
            smtp.login(data['email_account'], data['email_password'])
            msg = MIMEMultipart()
            msg['From'] = data['email_account']
            msg['To'] = email['email']
            msg['Subject'] = "Customized Email"
            content = email_content.format(**email)
            msg.attach(MIMEText(content, 'plain'))
            smtp.send_message(msg)
        except Exception as e:
            print(f"Failed to send email to {email['email']}: {e}")
        finally:
            smtp.quit()
    return jsonify({"status": "Emails Sent!"})

if __name__ == '__main__':
    app.run(debug=True)

# Add your configuration details here
# Example: API keys, SMTP credentials, etc.

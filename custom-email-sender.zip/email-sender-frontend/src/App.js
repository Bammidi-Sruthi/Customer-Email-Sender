import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [file, setFile] = useState(null);
  const [columns, setColumns] = useState([]);
  const [emailContent, setEmailContent] = useState('');
  const [emails, setEmails] = useState([]);

  const uploadData = async () => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await axios.post('http://localhost:5000/upload-data', formData);
    setColumns(response.data.columns);
  };

  const sendEmails = async () => {
    const response = await axios.post('http://localhost:5000/send-email', {
      email_content: emailContent,
      emails: emails,
      email_account: "your-email@gmail.com",
      email_password: "your-password",
    });
    alert(response.data.status);
  };

  return (
    <div>
      <h1>Custom Email Sender</h1>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={uploadData}>Upload Data</button>
      <textarea placeholder="Enter email template..." onChange={(e) => setEmailContent(e.target.value)} />
      <button onClick={sendEmails}>Send Emails</button>
    </div>
  );
}

export default App;
